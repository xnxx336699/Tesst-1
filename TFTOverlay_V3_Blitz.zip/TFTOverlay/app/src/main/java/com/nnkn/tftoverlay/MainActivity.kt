package com.nnkn.tftoverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtUrl = findViewById<EditText>(R.id.edtUrl)
        edtUrl.setText(BuildConfig.DATA_URL)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val url = edtUrl.text.toString().trim()
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("data_url", url).apply()
            Toast.makeText(this, "Đã lưu URL dữ liệu", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
                Toast.makeText(this, "Hãy bật quyền 'Hiển thị trên ứng dụng khác'", Toast.LENGTH_LONG).show()
            } else {
                val svc = Intent(this, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
                Toast.makeText(this, "Đã bật bong bóng overlay", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}

package com.nnkn.tftoverlay.net

import android.content.Context
import com.google.gson.*
import com.nnkn.tftoverlay.data.Comp
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Url
import java.lang.reflect.Type

class BlitzClient(private val ctx: Context, private val fullUrl: String) {

    private val api: RawApi by lazy {
        val log = HttpLoggingInterceptor()
        log.level = HttpLoggingInterceptor.Level.BASIC
        val ok = OkHttpClient.Builder().addInterceptor(log).build()
        Retrofit.Builder()
            .baseUrl("https://dummy-base/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(ok)
            .build()
            .create(RawApi::class.java)
    }

    interface RawApi {
        @GET
        suspend fun getRaw(@Url url: String): JsonElement
    }

    /** Fetch and normalize to a list of [Comp]. */
    suspend fun fetchComps(): List<Comp> {
        return try {
            val json = api.getRaw(fullUrl)
            normalize(json)
        } catch (e: Exception) {
            e.printStackTrace()
            // fallback to local bundled JSON (simple schema)
            val ins = ctx.resources.openRawResource(com.nnkn.tftoverlay.R.raw.comps_fallback)
            val txt = ins.bufferedReader().readText()
            val arr = JsonParser.parseString(txt).asJsonArray
            arr.map {
                val o = it.asJsonObject
                Comp(
                    name = o["name"].asString,
                    description = o["description"].asString,
                    units = o["units"].asJsonArray.map { u -> u.asString }
                )
            }
        }
    }

    /** Heuristic to parse a few possible Blitz/TFT schemas into [Comp]. */
    private fun normalize(el: JsonElement): List<Comp> {
        val out = mutableListOf<Comp>()
        if (el.isJsonArray) {
            // assume array of comps already
            for (e in el.asJsonArray) {
                val o = e.asJsonObject
                val name = o.get("name")?.asString ?: o.get("title")?.asString ?: "Comp"
                val desc = o.get("description")?.asString ?: o.get("shortDesc")?.asString ?: ""
                val units = when {
                    o.has("units") -> o.getAsJsonArray("units").map { it.asString }
                    o.has("champions") -> o.getAsJsonArray("champions").map { it.asString }
                    else -> emptyList()
                }
                out.add(Comp(name, desc, units))
            }
        } else if (el.isJsonObject) {
            val root = el.asJsonObject
            // try set.comps shape: { comps: [ { name, champions:[...] } ] }
            if (root.has("comps")) {
                for (c in root.getAsJsonArray("comps")) {
                    val o = c.asJsonObject
                    val name = o.get("name")?.asString ?: "Comp"
                    val desc = o.get("description")?.asString ?: ""
                    val units = if (o.has("champions")) o.getAsJsonArray("champions").map { it.asString } else emptyList()
                    out.add(Comp(name, desc, units))
                }
            } else if (root.has("data")) {
                // some endpoints wrap results in data
                return normalize(root["data"])
            }
        }
        return out
    }
}
